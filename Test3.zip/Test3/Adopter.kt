package com.example.assesment3

import android.content.Context
import androidx.fragment.app.Fragment

class Adopter( private val context : Context) {

}